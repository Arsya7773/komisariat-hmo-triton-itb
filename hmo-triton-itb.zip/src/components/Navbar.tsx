import React from 'react';
import { motion } from 'motion/react';
import { Lock } from 'lucide-react';
import { cn } from '@/src/lib/utils';

export const Navbar = () => {
  return (
    <nav className="glass-nav px-8 py-4 flex items-center justify-between">
      <div className="flex items-center gap-4">
        {/* Logo with Gradient as per design */}
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-full bg-gradient-to-br from-accent-blue to-gold flex items-center justify-center text-[10px] font-bold text-white shadow-lg">
            HMO
          </div>
          <span className="font-serif text-white text-lg font-bold tracking-tight">HMO TRITON ITB</span>
        </div>
      </div>

      <div className="hidden md:flex items-center gap-8 text-[11px] uppercase tracking-widest font-semibold text-white/70">
        {['Profil', 'Program', 'Kabar Himpunan', 'Kontak'].map((item) => (
          <a
            key={item}
            href={`#${item.toLowerCase()}`}
            className={cn(
              "hover:text-gold transition-colors pb-1 border-b-2 border-transparent",
              item === 'Profil' ? "text-white border-gold" : ""
            )}
          >
            {item}
          </a>
        ))}
      </div>

      <button className="p-2 rounded bg-white/5 border border-white/10 text-white/50 hover:text-white transition-all">
        <Lock size={16} />
      </button>
    </nav>
  );
};
