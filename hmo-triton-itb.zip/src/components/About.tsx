import React from 'react';
import { motion } from 'motion/react';
import { Compass, Shield, Target } from 'lucide-react';

export const About = () => {
  const sections = [
    { title: 'Sejarah', icon: <Compass size={24} className="text-gold" />, desc: 'Berdiri sebagai wadah pemersatu mahasiswa Oseanografi ITB sejak tahun 1990.' },
    { title: 'Asas', icon: <Shield size={24} className="text-accent-blue" />, desc: 'Berdasarkan Pancasila dan berlandaskan kekeluargaan serta profesionalisme.' },
    { title: 'Tujuan', icon: <Target size={24} className="text-navy-deep" />, desc: 'Membentuk insan akademis yang sadar akan tanggung jawab kemaritiman Indonesia.' },
  ];

  return (
    <section id="profil" className="py-24 px-8 md:px-20 bg-[#0A192F] relative overflow-hidden">
      <div className="absolute inset-0 dots-pattern opacity-5 pointer-events-none" />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="grid lg:grid-cols-2 gap-20 items-center overflow-hidden">
          <motion.div
            initial={{ opacity: 0, x: -50 }}
            whileInView={{ opacity: 1, x: 0 }}
            viewport={{ once: true }}
            className="space-y-8"
          >
            <div className="space-y-4">
              <h2 className="text-5xl font-black italic text-white leading-none">
                PROFIL <br /> <span className="text-gold">HIMPUNAN</span>
              </h2>
              <div className="h-1.5 w-24 bg-gold" />
            </div>
            <p className="text-lg text-white/50 leading-relaxed font-light">
              Himpunan Mahasiswa Oseanografi "TRITON" ITB (HMO TRITON ITB) merupakan wadah berekspresi, berinovasi, dan berkontribusi bagi seluruh mahasiswa Oseanografi di Institut Teknologi Bandung.
            </p>
            <div className="grid gap-4">
              {sections.map((s, i) => (
                <div key={i} className="flex gap-4 p-6 rounded-2xl bg-white/5 border border-white/5 hover:border-gold/30 transition-all group backdrop-blur-sm">
                  <div className="p-3 rounded-xl bg-[#0A192F] ring-1 ring-white/10 group-hover:ring-gold/50 transition-all">
                    {s.icon}
                  </div>
                  <div>
                    <h4 className="font-bold text-white mb-1">{s.title}</h4>
                    <p className="text-sm text-white/40">{s.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            whileInView={{ opacity: 1, scale: 1 }}
            viewport={{ once: true }}
            className="relative"
          >
            <div className="aspect-[4/5] bg-navy-dark rounded-[40px] overflow-hidden shadow-2xl relative z-10">
              <img
                src="https://picsum.photos/seed/ocean/1200/1500"
                alt="Oceanography Students"
                className="w-full h-full object-cover opacity-80"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-navy-dark/80 to-transparent" />
              <div className="absolute bottom-8 left-8 p-6 bg-white/10 backdrop-blur-md rounded-2xl border border-white/20">
                <p className="text-white text-2xl font-serif italic italic font-bold">"Daya Biru"</p>
                <p className="text-white/60 text-xs uppercase tracking-widest mt-1">Kabinet 2023/2024</p>
              </div>
            </div>
            <div className="absolute -top-10 -right-10 w-64 h-64 bg-gold/5 rounded-full blur-3xl -z-10" />
            <div className="absolute -bottom-10 -left-10 w-64 h-64 bg-accent-blue/5 rounded-full blur-3xl -z-10" />
          </motion.div>
        </div>
      </div>
    </section>
  );
};
