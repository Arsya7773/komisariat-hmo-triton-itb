import React from 'react';
import { motion } from 'motion/react';
import { Users, GraduationCap, Globe2, Anchor } from 'lucide-react';

export const Programs = () => {
  const progs = [
    { title: 'POSEIDON', icon: <Anchor />, color: 'bg-navy-dark', desc: 'Pengembangan kurikulum dan riset kelautan terpadu bagi anggota.' },
    { title: 'Parade Wisuda HMO', icon: <GraduationCap />, color: 'bg-gold', desc: 'Apresiasi dan penghormatan bagi seluruh lulusan Oseanografi ITB.' },
    { title: 'Senator Komisariat', icon: <Users />, color: 'bg-accent-blue', desc: 'Representasi diplomatik himpunan di tingkat universitas dan pusat.' },
    { title: 'Wyrtki HMO', icon: <Globe2 />, color: 'bg-teal-600', desc: 'Program pengabdian masyarakat pesisir dan edukasi maritim.' },
  ];

  return (
    <section id="program" className="py-24 px-8 md:px-20 bg-navy-dark relative overflow-hidden">
      <div className="absolute inset-0 bg-[#D4AF37]/5 pointer-events-none blur-[100px]" />
      <div className="max-w-7xl mx-auto text-center mb-16 space-y-4 relative z-10">
        <h2 className="text-5xl font-black italic text-white leading-none">
          PROGRAM UNGGULAN
        </h2>
        <p className="text-white/40 font-medium max-w-xl mx-auto italic">
          Inisiatif strategis Kabinet Daya Biru untuk memperkuat sinergi dan inovasi dalam lingkup maritim.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 relative z-10">
        {progs.map((p, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ delay: i * 0.1 }}
            viewport={{ once: true }}
            whileHover={{ y: -10 }}
            className="bg-white/5 p-8 rounded-[32px] border border-white/10 shadow-2xl backdrop-blur-sm flex flex-col items-center group cursor-pointer hover:border-gold/30 transition-all"
          >
            <div className={`p-5 rounded-2xl text-white mb-6 transition-all group-hover:scale-110 group-hover:rotate-6 bg-gradient-to-br ${p.color === 'bg-navy-dark' ? 'from-[#3B82F6] to-navy-dark' : p.color === 'bg-gold' ? 'from-[#D4AF37] to-gold/50' : 'from-accent-blue to-navy-deep'}`}>
              {React.cloneElement(p.icon as React.ReactElement, { size: 28 })}
            </div>
            <h4 className="text-xl font-bold text-white mb-4 uppercase tracking-tight">{p.title}</h4>
            <p className="text-sm text-white/40 leading-relaxed font-light text-center">
              {p.desc}
            </p>
          </motion.div>
        ))}
      </div>
    </section>
  );
};
