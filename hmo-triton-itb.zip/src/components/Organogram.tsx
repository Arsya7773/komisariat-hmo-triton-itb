import React from 'react';
import { motion } from 'motion/react';
import { ChevronLeft, ChevronRight, User } from 'lucide-react';

export const Organogram = () => {
  const divisions = [
    { title: 'Ketua Himpunan', name: 'Adrevi Chepa', role: 'Chairman', color: 'bg-navy-dark' },
    { title: 'Internal', name: 'Divisi Internal', role: 'Pengembangan Anggota', color: 'bg-accent-blue' },
    { title: 'Eksternal', name: 'Divisi Eksternal', role: 'Hubungan Luar', color: 'bg-gold' },
    { title: 'Medkominfo', name: 'Divisi Medkominfo', role: 'Propaganda & Media', color: 'bg-teal-600' },
    { title: 'Kewirausahaan', name: 'Divisi KWU', role: 'Financial Stability', color: 'bg-orange-500' },
    { title: 'Minat Bakat', name: 'Divisi Mibat', role: 'Hobbies & Sports', color: 'bg-purple-600' },
  ];

  const scrollRef = React.useRef<HTMLDivElement>(null);

  const scroll = (dir: 'l' | 'r') => {
    if (scrollRef.current) {
      const scrollAmount = 300;
      scrollRef.current.scrollBy({ left: dir === 'l' ? -scrollAmount : scrollAmount, behavior: 'smooth' });
    }
  };

  return (
    <section className="py-24 px-8 md:px-20 bg-[#0A192F] relative overflow-hidden">
      <div className="absolute inset-0 dots-pattern opacity-5 pointer-events-none" />
      <div className="max-w-7xl mx-auto relative z-10">
        <div className="flex items-end justify-between mb-16">
          <div className="space-y-4">
            <h2 className="text-5xl font-black italic text-white leading-none uppercase tracking-tighter">
              STRUKTUR <br /> <span className="text-gold">KEPENGURUSAN</span>
            </h2>
            <div className="h-1.5 w-32 bg-accent-blue" />
          </div>
          <div className="flex gap-4">
            <button onClick={() => scroll('l')} className="p-4 rounded-full border border-white/10 hover:bg-white/5 transition-all text-white">
              <ChevronLeft size={20} />
            </button>
            <button onClick={() => scroll('r')} className="p-4 rounded-full border border-white/10 hover:bg-white/5 transition-all text-white">
              <ChevronRight size={20} />
            </button>
          </div>
        </div>

        <div 
          ref={scrollRef}
          className="flex gap-8 overflow-x-auto pb-12 hide-scrollbar snap-x snap-mandatory"
        >
          {divisions.map((d, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: 50 }}
              whileInView={{ opacity: 1, x: 0 }}
              transition={{ delay: i * 0.1 }}
              viewport={{ once: true }}
              className="min-w-[300px] snap-center p-10 rounded-[40px] border border-white/5 bg-white/5 shadow-2xl backdrop-blur-md flex flex-col items-center group relative overflow-hidden hover:border-gold/30 transition-all"
            >
              <div className={`absolute top-0 right-0 w-32 h-32 opacity-10 blur-3xl -z-10 ${d.color}`} />
              
              <div className={`w-28 h-28 rounded-full mb-8 flex items-center justify-center ring-4 ring-white/5 shadow-2xl overflow-hidden ${d.color}`}>
                <User size={48} className="text-white opacity-20" />
              </div>
              
              <h4 className="text-[10px] font-bold text-white/30 uppercase tracking-[0.2em] mb-2">{d.title}</h4>
              <p className="text-xl font-bold text-white text-center leading-tight mb-2 uppercase font-serif italic">{d.name}</p>
              <span className="text-[9px] font-bold text-gold italic uppercase tracking-[0.15em] bg-gold/10 px-4 py-1.5 rounded-full ring-1 ring-gold/20">
                {d.role}
              </span>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};
