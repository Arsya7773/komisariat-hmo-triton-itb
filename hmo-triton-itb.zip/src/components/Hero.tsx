import React from 'react';
import { motion } from 'motion/react';
import { ChevronRight } from 'lucide-react';

export const Hero = () => {
  return (
    <section className="relative min-h-[90vh] bg-gradient-to-b from-[#0A192F] via-[#002B5B] to-[#0A192F] overflow-hidden flex items-center px-8 md:px-20">
      {/* Immersive Background Elements */}
      <div className="absolute inset-0 dots-pattern opacity-10 pointer-events-none" />
      <div className="absolute top-0 right-0 w-[600px] h-[600px] bg-accent-blue/10 rounded-full blur-[120px] -mr-48 -mt-48 pointer-events-none" />
      <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-gold/5 rounded-full blur-[100px] -ml-24 -mb-24 pointer-events-none" />

      <div className="relative z-10 max-w-6xl w-full">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="grid lg:grid-cols-12 gap-12 items-center"
        >
          <div className="lg:col-span-8">
            <span className="inline-block px-3 py-1 rounded-full border border-gold/30 bg-gold/10 text-gold text-[10px] font-bold uppercase tracking-[0.2em] mb-6">
              Kabinet Daya Biru
            </span>
            <h1 className="text-7xl md:text-8xl font-black text-white leading-tight mb-6 tracking-tighter italic font-serif">
              HMO TRITON ITB
            </h1>
            <p className="text-xl md:text-2xl text-accent-blue font-light italic leading-relaxed mb-10 max-w-xl">
              Mengembangkan Potensi, Meningkatkan Eksistensi. Memajukan Ilmu Kelautan Indonesia.
            </p>
            <div className="flex flex-wrap gap-4 mb-16">
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-gold text-navy-dark px-10 py-4 rounded font-bold text-sm tracking-wide gold-shadow-hover transition-all uppercase"
              >
                Jelajahi TRITON
              </motion.button>
              <motion.button
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
                className="bg-white/5 border border-white/20 text-white px-10 py-4 rounded font-bold text-sm tracking-wide hover:bg-white/10 transition-all uppercase"
              >
                Visi & Misi
              </motion.button>
            </div>

            {/* Stats Section */}
            <div className="pt-12 grid grid-cols-3 gap-8 border-t border-white/10 max-w-2xl">
              {[
                { label: 'Anggota Aktif', val: '520+' },
                { label: 'Divisi Kerja', val: '12' },
                { label: 'Didirikan', val: '1976' }
              ].map((stat, i) => (
                <div key={i} className="space-y-1">
                  <div className="text-3xl font-serif text-gold font-bold">{stat.val}</div>
                  <div className="text-[10px] uppercase text-white/40 tracking-widest leading-tight">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Abstract Bathymetry textures could go here, but keeping it clean like the design */}
        </motion.div>
      </div>

      {/* Bathymetry Lines Visual */}
      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-1/3 opacity-30 select-none hidden lg:block">
        {[...Array(5)].map((_, i) => (
          <motion.div
            key={i}
            initial={{ opacity: 0, x: 50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ delay: 0.5 + i * 0.1, duration: 1 }}
            className="h-px bg-gradient-to-l from-accent-blue/50 to-transparent mb-12 transform -skew-x-[30deg] border-dashed border-b border-white/10"
          />
        ))}
      </div>
    </section>
  );
};
