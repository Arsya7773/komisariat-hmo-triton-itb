import React from 'react';
import { motion } from 'motion/react';
import { MapPin, Phone, Instagram, Twitter, Mail } from 'lucide-react';

export const Footer = () => {
  return (
    <footer id="kontak" className="bg-navy-dark pt-24 pb-12 px-8 md:px-20 relative overflow-hidden">
      <div className="max-w-7xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-16 relative z-10">
        {/* Brand & Address */}
        <div className="space-y-8">
          <div className="flex items-center gap-4">
            <div className="w-12 h-12 bg-white rounded-full flex items-center justify-center font-serif text-navy-dark font-bold text-[14px]">
              HMO
            </div>
            <div>
              <span className="block text-xl font-bold text-white font-serif uppercase leading-none">HMO TRITON</span>
              <span className="block text-[10px] font-medium text-white/50 uppercase tracking-widest mt-1">Oceanography ITB</span>
            </div>
          </div>
          <div className="space-y-4">
            <div className="flex gap-3 items-start">
              <MapPin className="text-gold shrink-0 mt-1" size={20} />
              <p className="text-white/60 text-sm leading-relaxed">
                Sekretariat HMO TRITON ITB,<br />
                Gedung Labtek XI Lantai 2,<br />
                Institut Teknologi Bandung,<br />
                Bandung, Jawa Barat.
              </p>
            </div>
            <div className="flex gap-3 items-center">
              <Phone className="text-accent-blue" size={18} />
              <p className="text-white/60 text-sm">+62 812 3456 7890 (Narahubung)</p>
            </div>
          </div>
        </div>

        {/* Dynamic Map UI (Mock) */}
        <div className="md:col-span-2">
          <div className="bg-white/5 rounded-[40px] p-2 aspect-[21/9] border border-white/10 relative overflow-hidden group">
            <div className="w-full h-full bg-navy-deep rounded-[36px] overflow-hidden flex items-center justify-center">
              <img 
                src="https://picsum.photos/seed/map/1200/500?grayscale" 
                alt="Map Background"
                className="w-full h-full object-cover opacity-20"
                referrerPolicy="no-referrer"
              />
              <div className="absolute inset-0 flex items-center justify-center">
                <motion.div 
                  animate={{ scale: [1, 1.2, 1] }}
                  transition={{ repeat: Infinity, duration: 2 }}
                  className="w-4 h-4 bg-accent-blue rounded-full relative"
                >
                  <div className="absolute inset-0 bg-accent-blue rounded-full animate-ping" />
                </motion.div>
                <div className="ml-4 p-3 bg-white rounded-xl shadow-2xl">
                  <span className="text-[10px] font-bold text-navy-dark uppercase tracking-tighter">Lokasi Sekre</span>
                </div>
              </div>
            </div>
          </div>
          
          {/* Social Social */}
          <div className="mt-8 flex gap-4">
            {[Instagram, Twitter, Mail].map((Icon, i) => (
              <a key={i} href="#" className="w-12 h-12 bg-white/5 rounded-full flex items-center justify-center text-white hover:bg-gold hover:text-navy-dark transition-all ring-1 ring-white/10">
                <Icon size={20} />
              </a>
            ))}
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto mt-24 pt-8 border-t border-white/5 flex flex-col md:flex-row justify-between items-center gap-6 text-[10px] text-white/30 uppercase tracking-[0.2em]">
        <p>© 2024 HMO TRITON ITB. All Rights Reserved.</p>
        <p className="flex items-center gap-2">
          Designed for <span className="text-white/60 font-bold italic">Daya Biru</span>
        </p>
      </div>
    </footer>
  );
};
