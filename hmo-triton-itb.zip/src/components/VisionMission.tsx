import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2 } from 'lucide-react';

export const VisionMission = () => {
  const missions = [
    'Mewujudkan HMO TRITON ITB yang sinergis dan kolaboratif antar elemen himpunan.',
    'Meningkatkan eksistensi dan peran HMO TRITON ITB secara internal maupun eksternal.',
    'Mengembangkan potensi anggota melalui wadah aspirasi yang inovatif dan terarah.',
    'Membangun lingkungan himpunan yang inklusif, apresiatif, dan berorientasi pada masa depan.'
  ];

  return (
    <section className="py-24 px-8 md:px-20 bg-navy-dark relative overflow-hidden">
      <div className="max-w-7xl mx-auto">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-12">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="space-y-4"
            >
              <span className="text-gold font-bold tracking-widest uppercase text-xs">Arah Masa Depan</span>
              <h2 className="text-6xl font-black italic text-white leading-none">
                VISI <br /> <span className="text-accent-blue">DAYA BIRU</span>
              </h2>
            </motion.div>
            
            <motion.div 
              initial={{ opacity: 0, scale: 0.95 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              className="p-10 bg-white/5 backdrop-blur-xl rounded-[40px] border border-white/10"
            >
              <p className="text-2xl md:text-3xl text-white/90 font-light italic leading-relaxed">
                "Mengembangkan <span className="text-gold font-bold">Potensi</span>, Meningkatkan <span className="text-accent-blue font-bold">Eksistensi</span> — Menuju HMO TRITON yang Progresif dan Berdampak."
              </p>
            </motion.div>
          </div>

          <div className="space-y-6">
            <h3 className="text-white text-sm font-bold uppercase tracking-widest mb-8 flex items-center gap-4">
               Misi Utama <div className="flex-1 h-px bg-white/10" />
            </h3>
            <div className="grid gap-4">
              {missions.map((mission, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: 30 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.1 }}
                  viewport={{ once: true }}
                  className="flex gap-4 p-6 bg-navy-deep rounded-2xl border border-white/5 hover:border-accent-blue/30 transition-colors group"
                >
                  <div className="mt-1">
                    <CheckCircle2 size={24} className="text-accent-blue group-hover:scale-110 transition-transform" />
                  </div>
                  <p className="text-white/80 font-medium leading-relaxed">
                    {mission}
                  </p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};
